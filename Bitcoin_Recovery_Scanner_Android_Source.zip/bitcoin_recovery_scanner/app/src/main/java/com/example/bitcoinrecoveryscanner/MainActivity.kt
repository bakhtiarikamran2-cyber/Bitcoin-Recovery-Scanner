package com.example.bitcoinrecoveryscanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.bitcoinrecoveryscanner.data.ApiFactory
import com.example.bitcoinrecoveryscanner.data.TxDetails
import kotlinx.coroutines.launch

private const val MIN_SATS = 10_000_000L // 0.1 BTC

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFF7931A))) { ScannerScreen() } }
    }
}

class ScannerViewModel : ViewModel() {
    var results by mutableStateOf<List<TxDetails>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var message by mutableStateOf("برای دریافت نمونه تراکنش‌های اخیر ممپول، اسکن را اجرا کنید.")
        private set

    fun scanRecentMempool() {
        viewModelScope.launch {
            loading = true
            message = "در حال دریافت نمونه‌های اخیر ممپول…"
            try {
                val recent = ApiFactory.api.recentMempool()
                val details = recent.mapNotNull { item ->
                    runCatching { ApiFactory.api.transaction(item.txid) }.getOrNull()
                }
                results = details.filter { !it.status.confirmed && it.totalOutputSats >= MIN_SATS }
                message = "بررسی ${details.size} تراکنش اخیر انجام شد؛ ${results.size} مورد با مجموع خروجی حداقل 0.1 BTC پیدا شد."
            } catch (e: Exception) {
                message = "خطا در دریافت داده: ${e.localizedMessage ?: "اتصال را بررسی کنید"}"
            } finally {
                loading = false
            }
        }
    }
}

@Composable
fun ScannerScreen(vm: ScannerViewModel = viewModel()) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("₿ Bitcoin Recovery Scanner", style = MaterialTheme.typography.headlineSmall)
            Text("Android • Mainnet • Analysis only", color = MaterialTheme.colorScheme.secondary)
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تنظیمات اسکن", style = MaterialTheme.typography.titleMedium)
                    Text("شروع تاریخی: بلاک پیدایش (Genesis Block)")
                    Text("حداقل مبلغ: 0.1 BTC")
                    Text("حالت: تحلیل و شناسایی؛ بدون دسترسی به کلید خصوصی")
                }
            }
            Button(onClick = vm::scanRecentMempool, enabled = !vm.loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (vm.loading) "در حال اسکن…" else "اسکن نمونه‌های اخیر ممپول")
            }
            Text(vm.message, style = MaterialTheme.typography.bodyMedium)
            Text("نتایج فعلی ممپول", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.results, key = { it.txid }) { tx ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("TXID: ${tx.txid}", style = MaterialTheme.typography.bodySmall)
                            Text("مجموع خروجی: ${"%.8f".format(tx.totalOutputSats / 100_000_000.0)} BTC")
                            Text("کارمزد: ${tx.fee} sat • اندازه: ${tx.vsize} vB")
                            Text("وضعیت: تأییدنشده در زمان دریافت داده", color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
            Text("محدودیت نسخه اولیه: این صفحه فقط نمونه‌های اخیر ارائه‌شده از سوی API عمومی را می‌سنجد، نه کل ممپول و نه کل تاریخ بلاک‌چین.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        }
    }
}
