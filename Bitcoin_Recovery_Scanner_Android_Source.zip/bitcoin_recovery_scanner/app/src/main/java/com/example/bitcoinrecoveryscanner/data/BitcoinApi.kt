package com.example.bitcoinrecoveryscanner.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

data class RecentMempoolTx(
    val txid: String,
    val fee: Long,
    val vsize: Int,
    val value: Long
)

data class TxOutput(val value: Long)
data class TxStatus(val confirmed: Boolean)
data class TxDetails(
    val txid: String,
    val fee: Long,
    val vsize: Int,
    val status: TxStatus,
    val vout: List<TxOutput>
) {
    // Sum of outputs, not a claim that the whole amount belongs to one recipient.
    val totalOutputSats: Long get() = vout.sumOf { it.value }
}

interface MempoolApi {
    @GET("mempool/recent")
    suspend fun recentMempool(): List<RecentMempoolTx>

    @GET("tx/{txid}")
    suspend fun transaction(@Path("txid") txid: String): TxDetails
}

object ApiFactory {
    val api: MempoolApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://mempool.space/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MempoolApi::class.java)
    }
}
